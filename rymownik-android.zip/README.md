# Rymownik – aplikacja na Androida

Notatnik rapera z podpowiedziami rymów (WebView + androidx.webkit).
APK buduje się automatycznie w GitHub Actions (.github/workflows/build.yml)
i pojawia się w zakładce Releases jako Rymownik.apk.

Lokalnie (Android Studio / Gradle 8.9 + JDK 17): `gradle assembleRelease`
Wynik: app/build/outputs/apk/release/app-release.apk
Klucz podpisu: app/rymownik.keystore (hasło: rymownik123) – ten sam przy każdej wersji,
dzięki czemu aktualizacje instalują się bez utraty tekstów.
